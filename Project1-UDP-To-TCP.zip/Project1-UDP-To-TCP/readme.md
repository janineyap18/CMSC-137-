/*****

Janine D. Yap
2008-09596
CMSC 137 B-3L
Project 1: UDP To TCP Emulator using Socket Programming
References:
http://phoenix.goucher.edu/~kelliher/s2011/cs325/feb25.html
http://www.howtogeek.com/190014/htg-explains-what-is-the-difference-between-tcp-and-udp/
http://www.nylxs.com/docs/cmpnet.pdf
http://www.tcpipguide.com/free/t_TCPConnectionEstablishmentProcessTheThreeWayHandsh-3.htm

*****/


To Compile: 

Compile both the server and client code. 

For the server:
$ javac UDPServer.java
$ java UDPServer.java

For the client:
$ javac UDPClient.java
$ java UDPClient.java
