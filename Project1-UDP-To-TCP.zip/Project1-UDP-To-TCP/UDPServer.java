/*****

Janine D. Yap
2008-09596
CMSC 137 B-3L
Project 1: UDP To TCP Emulator using Socket Programming
References:
http://phoenix.goucher.edu/~kelliher/s2011/cs325/feb25.html
http://www.howtogeek.com/190014/htg-explains-what-is-the-difference-between-tcp-and-udp/
http://www.nylxs.com/docs/cmpnet.pdf
http://www.tcpipguide.com/free/t_TCPConnectionEstablishmentProcessTheThreeWayHandsh-3.htm

*****/

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Random;

public class UDPServer {
	int synBit, ackBit, finishBit, synNum, ackNum;
	int wSize = 3;
	String status = "";
    static String dataToSend = "Hello World!";
	
	static DatagramSocket serverSocket;
	static DatagramPacket serverPacket;
    static byte[] sendData = new byte[1024];
    static byte[] receiveData = new byte[1024];
    int[] dropProbability = {0,25,50,75,100};
	
	public UDPServer(){
		try {
			serverSocket = new DatagramSocket(10224);
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		serverPacket = new DatagramPacket(sendData, sendData.length);
		
		synNum = 0;
		ackNum = 0;
		synBit = 0;
		ackBit = 0;
		finishBit = 0;
	}

	public void waitConnection(){
		System.out.println("Waiting for client connection...");
		System.out.println("Doing 3-way handshake...");
		
		try {
			serverSocket.receive(serverPacket);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		receiveData = serverPacket.getData();
		String receivedData = new String(receiveData);
		System.out.println("Received data from client: "+receivedData);
		
		String[] data = receivedData.split("\\|");
		System.out.println(Integer.parseInt(data[0]));
		ackNum = Integer.parseInt(data[0]) + 1;
		
		ackBit = 1;
		
		Random rand = new Random();
		synNum = rand.nextInt(1000);
		synBit = 1;
		
		status = "";
		status = synNum+"|"+ackNum+"|"+synBit+"|"+ackBit+"|"+finishBit;
		sendData = status.getBytes();
		serverPacket.setData(sendData);
		
		try {
			System.out.println("Sending data to client.. "+status);
			serverSocket.send(serverPacket);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			serverSocket.receive(serverPacket);
			System.out.println(new String (serverPacket.getData()));
			System.out.println("Connection established with client.");
			
			sendData();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void run(){
		byte[] getData = new byte[1024];
		System.out.println("Waiting for connection...");
		
		while(true){
			try {
				serverSocket.receive(serverPacket);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			getData = serverPacket.getData();
			System.out.println(new String(getData));
		}
	}
	
	public void sendData(){
		Random random = new Random();
		int dropConnection = dropProbability[random.nextInt(5)];
		
		sendData = dataToSend.getBytes();
		int length = sendData.length;
		int quo = length / wSize;
		int rem = length % wSize;
		
		if(rem != 0) quo++;
		
		int i = 0;
		while(i<quo){
			for(int j=0; j<wSize; j++){
				try{
					byte[] perByte = new byte[1];
					perByte[0] = sendData[(i*wSize)+j];
					
					String toSend = ((i*wSize)+j)+"|"+new String(perByte);
					perByte = toSend.getBytes();
					
					System.out.println("Sending >>> "+ new String(perByte));
        		 	serverPacket.setData(perByte);
        		 	
        		 	if(random.nextInt(100) <= dropConnection){
        		 		System.out.println("The packet was dropped "+dropConnection+"%!");
        		 	} else {
        		 		serverSocket.send(serverPacket);
        		 	}
        		 	
        		 	Thread.sleep(2000);
        		 	
				}catch(Exception e){ 
					System.out.println("Finished getting the files!");
					break;
				}
			}
			
			for(int k=0; k<wSize; k++){
				try{
					serverSocket.setSoTimeout(4000);
					serverSocket.receive(serverPacket);
					System.out.println("Received ackBit: "+new String(serverPacket.getData()));
					
				} catch (IOException e){
					System.out.println("Timeout lapsed. Resending window...");
					i--;
					break;
				}
			}
			
			i++;
		}
	}
	
	public static void main(String args[]) throws Exception{
	       UDPServer server = new UDPServer();
	       
	       server.waitConnection();
	    }
}
