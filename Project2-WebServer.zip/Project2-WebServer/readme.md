/*****

Janine D. Yap
2008-09596
CMSC 137 B-3L
Project 2: Mini Web Server using Socket Programming
Reference: https://www.tutorialspoint.com/java/java_networking.htm

*****/


To Compile: 
$ javac WebServer.java
$ java WebServer <port number>